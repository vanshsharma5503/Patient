//
//  testApp.swift
//  test
//
//  Created by SHHH!! private on 02/05/24.
//

import SwiftUI
import FirebaseCore
@main
struct testApp: App {
    init(){
        FirebaseApp.configure()
    }
    var body: some Scene {
        WindowGroup {
            RecordsView()
        }
    }
}
