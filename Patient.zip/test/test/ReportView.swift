//
//  ReportView.swift
//  test
//
//  Created by SHHH!! private on 02/05/24.
//

import SwiftUI

struct Report: Identifiable {
    let id = UUID()
    let testName: String
    let date: String
    let time: String
    let doctorName: String
    let image: String
    let imageURL: String // Assuming imageURL is the URL of the image in Firebase Storage
    let doctorDepartment: String
}

struct ReportRow: View {
    let report: Report
    
    var body: some View {
        HStack {
            if report.testName == "Blood Test" {
                Image("blood")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .aspectRatio(contentMode: .fit)
            } else if report.testName == "X-Ray" {
                Image("Xray")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .aspectRatio(contentMode: .fit)
            } else if report.testName == "Biopsy" {
                Image("Biopsy")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .aspectRatio(contentMode: .fit)
            } else if report.testName == "CT Scan " {
                Image("Ctscan")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .aspectRatio(contentMode: .fit)
            } else if report.testName == "Endoscopic" {
                Image("Endoscopic")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .aspectRatio(contentMode: .fit)
            } else if report.testName == "Neurological" {
                Image("Neuro")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .aspectRatio(contentMode: .fit)
            } else if report.testName == "Cardiology" {
                Image("Cardiac")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .aspectRatio(contentMode: .fit)
            } else if report.testName == "Cancer Test" {
                Image("Cancer")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .aspectRatio(contentMode: .fit)
            }else {
                Image("mri")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .aspectRatio(contentMode: .fit)
            }
            Text(report.testName)
                .font(.headline)
            Spacer()
            Image(systemName: "chevron.right")
        }
        .padding()
    }
}
struct ReportsView: View {
    let searchText: String
    @State private var isShowingReportDetailView = false
    @State private var selectedReport: Report?

    let reports = [
        Report(testName: "Blood Test", date: "April 22, 2024", time: "10:00 AM", doctorName: "Dr. John Doe", image: "", imageURL: "https://example.com/image.jpg", doctorDepartment: "anesthesia"),
        Report(testName: "Biopsy", date: "April 22, 2024", time: "11:00 AM", doctorName: "Dr. Jane Smith", image: "", imageURL: "https://example.com/image.jpg", doctorDepartment: "orthopedics"),
        Report(testName: "X-Ray", date: "April 22, 2024", time: "11:00 AM", doctorName: "Dr. Jane Smith", image: "", imageURL: "https://example.com/image.jpg", doctorDepartment: "orthopedics"),
        Report(testName: "CT Scan ", date: "April 22, 2024", time: "11:00 AM", doctorName: "Dr. Jane Smith", image: "", imageURL: "https://example.com/image.jpg", doctorDepartment: "orthopedics"),
        Report(testName: "Endoscopic", date: "April 22, 2024", time: "11:00 AM", doctorName: "Dr. Jane Smith", image: "", imageURL: "https://example.com/image.jpg", doctorDepartment: "orthopedics"),
        Report(testName: "Neurological", date: "April 22, 2024", time: "11:00 AM", doctorName: "Dr. Jane Smith", image: "", imageURL: "https://example.com/image.jpg", doctorDepartment: "orthopedics"),
        Report(testName: "Cardiology", date: "April 22, 2024", time: "11:00 AM", doctorName: "Dr. Jane Smith", image: "", imageURL: "https://example.com/image.jpg", doctorDepartment: "orthopedics"),
        Report(testName: "Cancer Test", date: "April 22, 2024", time: "11:00 AM", doctorName: "Dr. Jane Smith", image: "", imageURL: "https://example.com/image.jpg", doctorDepartment: "orthopedics"),
        Report(testName: "MRI", date: "April 22, 2024", time: "11:00 AM", doctorName: "Dr. Jane Smith", image: "", imageURL: "https://example.com/image.jpg", doctorDepartment: "orthopedics"),
        // Add more reports as needed
    ]

    var filteredReports: [Report] {
        if searchText.isEmpty {
            return reports
        } else {
            return reports.filter { $0.testName.localizedCaseInsensitiveContains(searchText) }
        }
    }

    var body: some View {
        NavigationView {
            List(filteredReports) { report in
                ReportRow(report: report)
                    .onTapGesture {
                        selectedReport = report
                        isShowingReportDetailView = true
                    }
            }
            .sheet(isPresented: $isShowingReportDetailView) {
                VStack{
                    HStack{
                        Button("cancel"){
                            isShowingReportDetailView=false
                        }
                        .font(.system(size: 20))
                        .foregroundColor(.blue)
                        .padding()
                        .offset(x:150)
                    }
                    if let selectedReport = selectedReport {
                        ReportDetailView(report: selectedReport)
                    }
                    Spacer()
                }
            }
        }
    }
}
struct SearchableReportsView: View {
    @Binding var searchText: String

    let reports = [
        Report(testName: "Blood Test", date: "April 22, 2024", time: "10:00 AM", doctorName: "Dr. John Doe", image: "", imageURL: "https://example.com/image.jpg", doctorDepartment: "anesthesia"),
        // Add more reports as needed
    ]

    var body: some View {
        NavigationView {
            List(reports.filter { reportMatchesSearch($0) }) { report in
                ReportRow(report: report)
            }
        }
    }

    private func reportMatchesSearch(_ report: Report) -> Bool {
        let searchStringLowercased = searchText.lowercased()
        return report.testName.lowercased().contains(searchStringLowercased)
        // Add more conditions as needed
    }
}

struct ReportDetailView: View {
    let report: Report
    @State var tests: [PressTest] = []

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                ForEach(tests, id: \.id) { test in
                    TestView(test: test)
                    Divider()
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 10)
        }
        .navigationTitle("Reports")
        .onAppear {
            provideTests()
        }
    }

    func provideTests() {
        // Filter tests based on the type of the report
        tests = TestData.allTests.filter { $0.type == report.testName }
    }
}

struct TestView: View {
    let test: PressTest

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10)
                .foregroundColor(.white)
                .frame(width: 360, height: 120)
                .shadow(radius: 5)

            HStack {
                VStack(alignment: .leading) {
                    Text(test.name)
                        .font(.headline)
                        .bold()
                        .foregroundColor(.blue)

                    Text("Date: \(test.date)")
                        .font(.subheadline)
                        .padding(.top, 3)

                    Text("Time: \(test.time)")
                        .padding(.top, 0)
                        .font(.subheadline)
                    Text("Type: \(test.type)")
                        .padding(.top, 0)
                        .font(.subheadline)
                        .foregroundColor(.black.opacity(0.6))
                }
                .padding(.leading, 10)
                Spacer()
                VStack {
                    Button(action: {
                        if let url = URL(string: test.pdfURLString) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Image(systemName: "square.and.arrow.down")
                            .foregroundColor(.black)
                            .font(.system(size: 30))
                    }
                    .buttonStyle(PlainButtonStyle())
                }
                .padding(.trailing, 10)
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 0)
    }
}

struct PressTest: Identifiable {
    var id = UUID()
    var name: String
    var date: String
    var time: String
    var type: String
    var pdfURLString: String
}

struct TestData {
    static let allTests: [PressTest] = [
        PressTest(name: "Backbone X-Ray Test", date: "30 April, 2024", time: "11:00 a.m.", type: "X-Ray", pdfURLString: "https://www.example.com/backbone_xray_test.pdf"),
        PressTest(name: "Complete Blood Count", date: "30 April, 2024", time: "12:00 p.m.", type: "Blood Test", pdfURLString: "https://www.example.com/complete_blood_count.pdf"),
        PressTest(name: "Blood Glucose Test", date: "28 April, 2024", time: "1:00 p.m.", type: "Blood Test", pdfURLString: "https://www.example.com/blood_glucose_test.pdf"),
        PressTest(name: "MRI Test", date: "28 April, 2024", time: "2:00 p.m.", type: "MRI", pdfURLString: "https://www.example.com/mri_test.pdf"),
        PressTest(name: "Thyroid Ultrasound", date: "20 April, 2024", time: "3:00 p.m.", type: "Ultrasound", pdfURLString: "https://www.example.com/thyroid_ultrasound.pdf"),
        PressTest(name: "Chest X-Ray Test", date: "06 May, 2024", time: "11:00 a.m.", type: "X-Ray", pdfURLString: "https://www.example.com/backbone_xray_test.pdf"),
    ]
}

struct ReportsView_Previews: PreviewProvider {
    static var previews: some View {
        ReportsView(searchText: "")
    }
}


