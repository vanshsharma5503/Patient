//
//  ContentView.swift
//  Medspatient
//
//  Created by SHHH!! private on 23/04/24.
//
import SwiftUI
import Firebase



struct Prescription {
    let diagnosis: String
    let medicines: [Medicine]
    let tests: [Test]
}

struct Medicine {
    
    let name: String
    let dosage: Int
    let details: String
    let selectedTimesOfDay: [String]
    let toBeTaken: String
}

struct Test {
    let name: String
}

func fetchPrescriptions(completion: @escaping ([Prescription]?, Error?) -> Void) {
    let db = Firestore.firestore()
    db.collection("prescriptions").getDocuments { querySnapshot, error in
        if let error = error {
            completion(nil, error)
            return
        }
        
        var prescriptions: [Prescription] = []
        for document in querySnapshot!.documents {
            let diagnosis = document["diagnosis"] as? String ?? ""
            let medicinesData = document["medicines"] as? [[String: Any]] ?? []
            let medicines = medicinesData.map { medicineData -> Medicine in
                let name = medicineData["name"] as? String ?? ""
                let dosage = medicineData["dosage"] as? Int ?? 0
                let details = medicineData["details"] as? String ?? ""
                let selectedTimesOfDay = medicineData["selectedTimesOfDay"] as? [String] ?? []
                let toBeTaken = medicineData["toBeTaken"] as? String ?? ""
                return Medicine(name: name, dosage: dosage, details: details, selectedTimesOfDay: selectedTimesOfDay, toBeTaken: toBeTaken)
            }
            let testsData = document["tests"] as? [[String: Any]] ?? []
            let tests = testsData.map { testData -> Test in
                let name = testData["name"] as? String ?? ""
                return Test(name: name)
            }
            let prescription = Prescription(diagnosis: diagnosis, medicines: medicines, tests: tests)
            prescriptions.append(prescription)
        }
        completion(prescriptions, nil)
    }
}

// WeekValue struct for managing weeks
struct WeekValue: Identifiable {
    var id: Int
    var date: [Date]
}
struct PrescriptionListView: View {
    @State var prescriptions: [Prescription] = []
    @State var selectedDate = Date()
    var body: some View {
        VStack {
            DateCalendarView(selectedDate: $selectedDate)
            
            List {
                ForEach(prescriptions.indices, id: \.self) { index in
                    let prescription = prescriptions[index]
                    HStack {
                        Image("pills")
                            .resizable()
                            .frame(width: 60, height: 60)
                        
                        VStack(alignment: .leading) {
                            ForEach(prescription.medicines.indices, id: \.self) { medicineIndex in
                                let medicine = prescription.medicines[medicineIndex]
                                Text("\(medicine.name)")
                                    .font(.system(size: 23))
                                    .fontWeight(.bold)
                                Text("Dosage: \(medicine.dosage)")
                                Text("Details: \(medicine.details)")
                                    .foregroundColor(.black.opacity(0.7))
                                Text("To be taken :\(medicine.toBeTaken)")
                                HStack() {
                                    Text("Times of Day:")
                                        .padding(.top, 4)
                                        .fontWeight(.bold)
                                    
                                    HStack(spacing:0){
                                        ForEach(["Morning", "Afternoon", "Night"], id: \.self) { timeOfDay in
                                            VStack {
                                                Image(systemName: timeOfDay.lowercased() == "morning" ? "sunrise.fill" : (timeOfDay.lowercased() == "afternoon" ? "sun.max.fill" : "moon.fill"))
                                                    .foregroundColor(timeOfDay.lowercased() == "morning" ? .yellow : (timeOfDay.lowercased() == "afternoon" ? .orange : .blue))
                                                
                                                Text(timeOfDay.prefix(1).capitalized)
                                                
                                                // Check if the time of day is present in selectedTimesOfDay
                                                let isPresent = medicine.selectedTimesOfDay.contains(timeOfDay)
                                                
                                                // Display indicator (1 if present, 0 if not)
                                                Text(isPresent ? "1" : "0")
                                                
                                                // Display whether it's taken before or after
                                            }
                                            .padding(.trailing, 20) // Add spacing between each time of day
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            .onAppear {
                fetchPrescriptions { fetchedPrescriptions, error in
                    if let fetchedPrescriptions = fetchedPrescriptions {
                        self.prescriptions = fetchedPrescriptions
                    } else if let error = error {
                        print("Error fetching prescriptions: \(error)")
                    }
                }
            }
        }
    }
}



// WeekStore class for managing weeks


struct MedicineTrackingPage_Previews: PreviewProvider {
    static var previews: some View {
//        MedicineTrackingPage()
        PrescriptionListView()
    }
}
