//
//  MedspatientApp.swift
//  Medspatient
//
//  Created by SHHH!! private on 23/04/24.
//

import SwiftUI
import FirebaseCore


@main
struct MedicineTrackingApp: App {
    init(){
        FirebaseApp.configure()
    }
    var body: some Scene {
        WindowGroup {
            PrescriptionListView()
        }
    }
}
