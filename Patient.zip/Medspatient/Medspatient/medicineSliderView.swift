//
//  medicineSliderView.swift
//  Medspatient
//
//  Created by SHHH!! private on 10/05/24.
//
import SwiftUI
import Firebase

struct Prescription1: Identifiable {
    let id = UUID() // Unique identifier for Prescription1
    let diagnosis: String
    let medicines: [Medicine1]
    let tests: [Test1]
    let appointmentDate: Date
}

struct Medicine1:Identifiable {
    let id = UUID()
    let name: String
    let dosage: Int
    let details: String
    let selectedTimesOfDay: [String]
    let toBeTaken: String
}

struct Test1 {
    let name: String
}

func fetchPrescriptions1(completion: @escaping ([Prescription1]?, Error?) -> Void) {
    let db = Firestore.firestore()
    db.collection("prescriptions").getDocuments { querySnapshot, error in
        if let error = error {
            completion(nil, error)
            return
        }
        
        var prescriptions: [Prescription1] = []
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" // Adjust date format based on Firestore data
        
        for document in querySnapshot!.documents {
            let diagnosis = document["diagnosis"] as? String ?? ""
            let appointmentDateString = document["appointmentDate"] as? String ?? ""
            
            // Convert appointmentDate string to Date
            guard let appointmentDate = dateFormatter.date(from: appointmentDateString) else {
                print("Error converting appointmentDate string to Date")
                continue
            }
            
            let medicinesData = document["medicines"] as? [[String: Any]] ?? []
            let medicines = medicinesData.map { medicineData -> Medicine1 in
                let name = medicineData["name"] as? String ?? ""
                let dosage = medicineData["dosage"] as? Int ?? 0
                let details = medicineData["details"] as? String ?? ""
                let selectedTimesOfDay = medicineData["selectedTimesOfDay"] as? [String] ?? []
                let toBeTaken = medicineData["toBeTaken"] as? String ?? ""
                return Medicine1(name: name, dosage: dosage, details: details, selectedTimesOfDay: selectedTimesOfDay, toBeTaken: toBeTaken)
            }
            let testsData = document["tests"] as? [[String: Any]] ?? []
            let tests = testsData.map { testData -> Test1 in
                let name = testData["name"] as? String ?? ""
                return Test1(name: name)
            }
            
            let prescription = Prescription1(diagnosis: diagnosis, medicines: medicines, tests: tests, appointmentDate: appointmentDate)
            prescriptions.append(prescription)
        }
        completion(prescriptions, nil)
    }
}
import SwiftUI
import Firebase

// Prescription1, Medicine1, Test1, fetchPrescriptions1 definitions...

struct MedicineSlider: View {
    @State var prescriptions: [Prescription1] = []
    @State var selectedDate = Date()
    
    var filteredPrescriptions: [Prescription1] {
        prescriptions.filter { prescription in
            Calendar.current.isDate(prescription.appointmentDate, inSameDayAs: selectedDate)
        }
    }
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            LazyHStack(spacing: 20) {
                ForEach(filteredPrescriptions) { prescription in
                    PrescriptionView(prescription: prescription)
                }
            }
            .padding()
        }
        .onAppear {
            fetchPrescriptions1 { fetchedPrescriptions, error in
                if let fetchedPrescriptions = fetchedPrescriptions {
                    self.prescriptions = fetchedPrescriptions
                } else if let error = error {
                    print("Error fetching prescriptions: \(error)")
                }
            }
        }
    }
}

struct PrescriptionView: View {
    let prescription: Prescription1
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Diagnosis: \(prescription.diagnosis)")
                .font(.headline)
            Text("Appointment Date: \(formattedDate(from: prescription.appointmentDate))")
                .font(.subheadline)
            
            ForEach(prescription.medicines) { medicine in
                MedicineBox(medicine: medicine)
            }
        }
        .frame(width: 200, height: 200)
        .padding()
        .background(Color.gray.opacity(0.1))
        .cornerRadius(8)
    }
    
    private func formattedDate(from date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        return dateFormatter.string(from: date)
    }
}

struct MedicineBox: View {
    let medicine: Medicine1
    
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(medicine.name)
                .font(.headline)
            Text("Dosage: \(medicine.dosage)")
                .foregroundColor(.black.opacity(0.7))
            Text("To be taken: \(medicine.toBeTaken)")
                .font(.subheadline)
            
            // Calculate dosages left based on current date and dosage
            Text("Dosages Left: \(dosagesLeft())")
                .font(.subheadline)
        }
    }
    
    // Function to calculate dosages left
    private func dosagesLeft() -> Int {
        // Assuming the dosage represents the total number of dosages without specific dates
        return medicine.dosage
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        MedicineSlider()
    }
}

//ForEach(prescription.medicines.indices, id: \.self) { medicineIndex in
//    let medicine = prescription.medicines[medicineIndex]
