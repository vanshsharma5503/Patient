//
//  ContentView.swift
//  PrescP
//
//  Created by SHHH!! private on 25/04/24.
//
import SwiftUI
import FirebaseFirestore

// Prescription model
struct Prescription {
    var doctorName: String
    var doctorSpecialty: String
    var symptoms: String
    var medication: [Medication]
    var tests: [Test]
    var suggestions: String
}

// Medication model
struct Medication: Identifiable {
    var id = UUID()
    var name: String
    var dosage: Int
    var selectedTimesOfDay: [String]
    var toBeTaken: String
}

// Test model
struct Test: Identifiable {
    var id = UUID()
    var name: String
}

struct PrescriptionView: View {
    @State private var prescription: Prescription?

    var body: some View {
        List {
            // Doctor Information
            Section(header: Text("Doctor Information")) {
                if let doctorName = prescription?.doctorName,
                   let doctorSpecialty = prescription?.doctorSpecialty {
                    HStack {
                        Image(systemName: "person.circle")
                            .resizable()
                            .frame(width: 50, height: 50)
                        VStack(alignment: .leading) {
                            Text(doctorName)
                                .font(.headline)
                            Text("Specialty: \(doctorSpecialty)")
                                .font(.subheadline)
                        }
                    }
                }
            }
            
            // Symptoms
            Section(header: Text("Symptoms")) {
                Text(prescription?.symptoms ?? "")
            }
            
            // Medication Details
            Section(header: Text("Medication Details")) {
                ForEach(prescription?.medication ?? []) { medication in
                    VStack(alignment: .leading) {
                        HStack{
                            Text("Medication:")
                                .fontWeight(.bold)
                            Text(medication.name)
                        }
                        HStack{
                            Text("Number of days:")
                                .fontWeight(.bold)
                            Text("\(medication.dosage)")
                        }
                        HStack{
                            Text("To be taken:")
                                .fontWeight(.bold)
                            Text("\(medication.toBeTaken)")
                        }
                        HStack(alignment:.center,
                               spacing:80) {
                            Text("Times of Day:")
                                .padding(.top, 4)
                                .fontWeight(.bold)
                            HStack{
                                ForEach(["Morning", "Afternoon", "Night"], id: \.self) { timeOfDay in
                                    VStack {
                                        Image(systemName: timeOfDay.lowercased() == "morning" ? "sunrise.fill" : (timeOfDay.lowercased() == "afternoon" ? "sun.max.fill" : "moon.fill"))
                                            .foregroundColor(timeOfDay.lowercased() == "morning" ? .yellow : (timeOfDay.lowercased() == "afternoon" ? .orange : .blue))
                                        Text(timeOfDay.prefix(1).capitalized)
                                        
                                        // Check if the time of day is present in selectedTimesOfDay
                                        let isPresent = medication.selectedTimesOfDay.contains(timeOfDay)
                                        
                                        // Display indicator (1 if present, 0 if not)
                                        Text(isPresent ? "1" : "0")
                                        
                                        // Display whether it's taken before or after
                                    }
                                    .padding(.trailing, 20) // Add spacing between each time of day
                                }
                            }
                        }
                    }
                }
            }
            
            // Test Names
            Section(header: Text("Test Names")) {
                ForEach(prescription?.tests ?? []) { test in
                    Text(test.name)
                }
            }
        }
        .listStyle(GroupedListStyle())
        .navigationTitle("Prescription")
        .onAppear {
            fetchPrescription()
        }
    }
    
    private func fetchPrescription() {
        let db = Firestore.firestore()
        let prescriptionRef = db.collection("prescriptions").document("Thm7Th1uJroN2tT9Xna6")

        prescriptionRef.getDocument { document, error in
            if let document = document, document.exists {
                let data = document.data()
                let doctorName = data?["doctorName"] as? String ?? ""
                let doctorSpecialty = data?["doctorSpecialty"] as? String ?? ""
                let symptoms = data?["symptoms"] as? String ?? ""
                let suggestions = data?["suggestions"] as? String ?? ""
                let medicationData = data?["medicines"] as? [[String: Any]] ?? []
                let medication = medicationData.map { medData -> Medication in
                    let name = medData["name"] as? String ?? ""
                    let dosage = medData["dosage"] as? Int ?? 0
                    let selectedTimesOfDay = medData["selectedTimesOfDay"] as? [String] ?? []
                    let toBeTaken = medData["toBeTaken"] as? String ?? ""
                    return Medication(name: name, dosage: dosage, selectedTimesOfDay: selectedTimesOfDay, toBeTaken: toBeTaken)
                }
                let testData = data?["tests"] as? [[String: Any]] ?? []
                let tests = testData.map { testData -> Test in
                    let name = testData["name"] as? String ?? ""
                    return Test(name: name)
                }
                
                self.prescription = Prescription(doctorName: doctorName, doctorSpecialty: doctorSpecialty, symptoms: symptoms, medication: medication, tests: tests, suggestions: suggestions)
            } else {
                print("Prescription document does not exist")
            }
        }
    }
}

struct PrescriptionView_Previews: PreviewProvider {
    static var previews: some View {
        PrescriptionView()
    }
}
