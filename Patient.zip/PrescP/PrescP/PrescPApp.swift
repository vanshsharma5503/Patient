//
//  PrescPApp.swift
//  PrescP
//
//  Created by SHHH!! private on 25/04/24.
//
import SwiftUI
import FirebaseCore


@main
struct PrescPApp: App {
    init(){
        FirebaseApp.configure()
    }
    var body: some Scene {
        WindowGroup {
            PrescriptionView()
        }
    }
}
